package HomePage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.junit.Assert;

public class VerifyURL {

	public static void main(String args[]) {

		System.setProperty("webdriver.chrome.driver", "D:\\jars1\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.get("https://www.hashtag-ca.com/careers/apply?jobCode=QAE001");
		driver.manage().window().maximize();
		
		//Check systems behavior when user enter valid URL
		String URL = driver.getCurrentUrl();
		Assert.assertEquals(URL,"https://www.hashtag-ca.com/careers/apply?jobCode=QAE001");
		System.out.println("URL is valid");
		
		
		//Check systems behavior when user enter invalid URL
		String URL1 = driver.getCurrentUrl();
		Assert.assertNotEquals(URL1,"http://plustag-ca.com/careers/apply?jobCode=QAE123");
		System.out.println("URL is invalid");

		driver.quit();
	}
}
