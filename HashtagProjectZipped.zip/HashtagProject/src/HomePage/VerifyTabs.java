package HomePage;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.concurrent.TimeUnit;

public class VerifyTabs {

	@SuppressWarnings("deprecation")
	public static void main(String args[]) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "D:\\\\jars1\\\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.hashtag-ca.com/careers/apply?jobCode=QAE001");
		driver.manage().window().maximize();
		//WebDriverWait w = new WebDriverWait(driver, 100);
		
		
		//User is verifying Service tab.
		WebElement serviceTab = driver.findElement(By.xpath("//*[text()='Services']"));
		serviceTab.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		
		//User is verifying Shopify tab
		WebElement shopifyTab = driver.findElement(By.xpath("//a[@class='nav-link ' and text()='Shopify ']"));	
		shopifyTab.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		
		//User is verifying Blog tab
		WebElement blogTab = driver.findElement(By.xpath("//a[@class='nav-link ' and @href='/blogs']"));
		blogTab.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		
		//User is verifying Careers tab
		WebElement careersTab = driver.findElement(By.xpath("//a[@class='nav-link ' and @href='/careers']"));
		careersTab.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
		
		//User is verifying Case Studies tab
		WebElement caseStudiesTab = driver.findElement(By.xpath("//a[@class='nav-link ' and @href='/casestudies']"));
		caseStudiesTab.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
		
		//User is verifying About Us tab
		WebElement aboutUsTab = driver.findElement(By.xpath("//a[@class='nav-link ' and @href='/about-us']"));
		aboutUsTab.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		
		//User is verifying Contact Us tab
		WebElement ContactUsTab = driver.findElement(By.xpath("//a[@class='nav-link ' and @href='/contact-us']"));
		ContactUsTab.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		driver.quit();
		
	}
	
}
