package HomePage;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Wait;
import org.junit.Assert;

public class VerifyJobForm {

	public static void main(String args[]) {

		System.setProperty("webdriver.chrome.driver", "D:\\jars1\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.get("https://www.hashtag-ca.com/careers/apply?jobCode=QAE001");
		driver.manage().window().maximize();

		WebElement nameField = driver.findElement(By.xpath("//input[@type='text' and @name='name']"));
		WebElement emailField = driver.findElement(By.xpath("//input[@type='email' and @name='email']"));
		WebElement phoneField = driver.findElement(By.xpath("//input[@type='number' and @name='phone']"));
		WebElement resumeButton = driver.findElement(By.xpath("//input[@type='file' and @name='resume']"));
		WebElement description = driver.findElement(By.xpath("//textarea[@name='description']"));
		WebElement applyNowButton = driver.findElement(By.xpath("//button[@class='btn form-button-child px-3']"));

		// User trying to verify the text fields present in Job Application using negative scenarios
		applyNowButton.click();
	
		// Unable to fetch error message due to some problem with link

		// User trying to verify Job Application form by entering all valid data
		nameField.sendKeys("Nayana");
		emailField.sendKeys("pawarnayanas@gmail.com");
		phoneField.sendKeys("9869000000");
		description.sendKeys("Quality Engineer with 3 years of IT experience in Automation testing as well as Manual Testing");
		applyNowButton.click();
		driver.quit();
	}
}
